package com.niit.shoppingcart;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcart.dao.UserDAO;
import com.niit.shoppingcart.model.User;

public class UserTest {
	
	public static void main(String args[])
	{
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.niit.*");
		context.refresh();
		
		User user= (User) context.getBean("user");
		UserDAO userDAO = (UserDAO) context.getBean("userDAO");
		
		user.setId("OG120");
		user.setAddress("OGADDRESS120");
		user.setMail("OGMAIL120");
		user.setMobile("OGMOBILE120");
		user.setName("OGNAME120");
		user.setPassword("OGPASSWORD120");
		
	}

}
