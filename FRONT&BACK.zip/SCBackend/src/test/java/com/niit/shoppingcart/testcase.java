package com.niit.shoppingcart;

import junit.framework.TestCase;

public class testcase extends TestCase {

}
