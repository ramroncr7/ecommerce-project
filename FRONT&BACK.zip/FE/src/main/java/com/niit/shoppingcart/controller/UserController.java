package com.niit.shoppingcart.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.niit.shoppingcart.dao.UserDAO;
import com.niit.shoppingcart.model.UserDetails;

public class UserController 
{
	//Logger log= LoggerFactory.getLogger(UserController.class);
	
	@Autowired
	UserDAO userDAO;
	
	@Autowired
	UserDetails userDetails;

	
	@RequestMapping("/login")
	public ModelAndView login(@RequestParam(value="name") String userID, 
			@RequestParam(value="password") String password)
	{
		return null;
	}

}