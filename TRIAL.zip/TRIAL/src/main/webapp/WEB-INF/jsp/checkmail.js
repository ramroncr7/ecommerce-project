
	function checkmail()
	{
		var email = document.getElementById("email").value;
		var x = document.forms["RegForm"]["email"].value;
		var atpos = x.indexOf("@");
		var dotpos = x.lastIndexOf(".");
		if (email == null || email == "") 
		{
           	 		alert("Please enter the email ID");
            			return false;
        }
		else if (atpos<1 || dotpos<atpos+2 || dotpos+2>=x.length) 
		{
			alert("Not a valid e-mail address");
			return false;
		}
		else
		{
			return true;
		}
	}
