function pswdcheck()
{
}