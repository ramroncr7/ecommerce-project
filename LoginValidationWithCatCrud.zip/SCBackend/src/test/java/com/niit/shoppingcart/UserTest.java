package com.niit.shoppingcart;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcart.dao.UserDAO;

import com.niit.shoppingcart.model.UserDetails;

public class UserTest {
	
	public static void main(String args[])
	{
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();
		
		UserDetails userDetails= (UserDetails) context.getBean("userDetails");
		UserDAO userDAO = (UserDAO) context.getBean("userDAO");
		
		userDetails.setId("niit");
		userDetails.setAddress("");
		userDetails.setMailID("");
		userDetails.setContactNumber("");
		userDetails.setName("Admin");
		userDetails.setPassword("niit");
		userDetails.setAdmin(true);
		userDAO.saveorUpdate(userDetails);
	}

}
