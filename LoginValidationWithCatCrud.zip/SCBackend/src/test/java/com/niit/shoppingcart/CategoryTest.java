package com.niit.shoppingcart;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcart.dao.CategoryDAO;
import com.niit.shoppingcart.model.Category;

public class CategoryTest {
	public static void main(String[] args)
	{
		AnnotationConfigApplicationContext context= new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();
		
		Category category = (Category) context.getBean("category");
		CategoryDAO categoryDAO =(CategoryDAO) context.getBean("categoryDAO");
		
		category.setId("CG03");
		category.setName("DELL");
		category.setDescription("DELL SERIES");
		
		categoryDAO.saveorUpdate(category);
		//categoryDAO.delete("CG120");
		
		if(categoryDAO.get("sdfsf") == null)
		{
			System.out.println("Category does not exist");
		}
		else
		{
			System.out.println("Category exists.... details are: ");
			System.out.println();
		}
	}
}
