package com.niit.shoppingcart;



import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcart.dao.SupplierDAO;
import com.niit.shoppingcart.model.Supplier;

public class SupplierTest {
	
	public static void main(String[] args)
	{
		AnnotationConfigApplicationContext context= new AnnotationConfigApplicationContext();
		context.scan("com.niit.shoppingcart");
		context.refresh();
		
		SupplierDAO supplierDAO =(SupplierDAO) context.getBean("supplierDAO");
		Supplier supplier = (Supplier) context.getBean("supplier");
		supplier.setID("CG120");
		supplier.setName("CGNAME120");
		supplier.setAddress("Chennai");
		supplierDAO.saveOrUpdate(supplier);
		//supplierDAO.delete("CG120");
		
		if(supplierDAO.get("sdfsf") == null)
		{
			System.out.println("Supplier does not exist");
		}
		else
		{
			System.out.println("Supplier exists.... details are: ");
			System.out.println();
		}
	}
}
