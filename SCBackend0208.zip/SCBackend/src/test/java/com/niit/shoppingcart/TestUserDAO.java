package com.niit.shoppingcart;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcart.dao.UserDAO;
import com.niit.shoppingcart.model.UserDetails;
import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
public class TestUserDAO {

	@Autowired
	static
	UserDAO userDAO;

	@Autowired
	static
	UserDetails userDetails;

	static AnnotationConfigApplicationContext context;

	@Before
	public static void init()
	{
		context=new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();
		
		userDAO = (UserDAO) context.getBean("userDAO");
		userDetails = (UserDetails) context.getBean("userDetails");
		
	}
	
	@After
	public static void close()
	{
		context.close();
		userDAO=null;
		userDetails=null;
	}
	
	//select count(*) from userDetails
	@Test
	public void UsersTestCase()
	{
		int size=	userDAO.list().size();
		assertEquals("User list test case",5,size);
		
	}
	
	@Test
	public void UserNameTestCase()
	{
		userDetails = userDAO.get("");
		String name = userDetails.getName();
		assertEquals("Name test case", "niit", name);
		
	}
	
}

