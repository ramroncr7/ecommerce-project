package com.niit.shoppingcart;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import com.niit.shoppingcart.dao.ProductDAO;
import com.niit.shoppingcart.model.Product;

public class ProductTest {
public static void main(String[] args) {
	AnnotationConfigApplicationContext context= new AnnotationConfigApplicationContext();
	context.scan("com.niit");
	context.refresh();
	
	Product product = (Product) context.getBean("product");
	ProductDAO productDAO =(ProductDAO) context.getBean("productDAO");
	
	product.setId("CG120");
	product.setName("CGNAME120");
	product.setDescription("CGDESC120");
	product.setPrice("CGPRICE120");
	
 productDAO.saveorUpdate(product);
	//categoryDAO.delete("CG120");
	
	if(productDAO.get("sdfsf") == null)
	{
		System.out.println("Product does not exist");
	}
	else
	{
		System.out.println("Product exists.... details are: ");
		System.out.println();
	}
}
}

