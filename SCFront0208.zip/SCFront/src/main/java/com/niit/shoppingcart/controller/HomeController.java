package com.niit.shoppingcart.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.method.support.ModelAndViewContainer;
import org.springframework.web.servlet.ModelAndView;

import com.niit.shoppingcart.dao.CategoryDAO;
import com.niit.shoppingcart.dao.SupplierDAO;

public class HomeController {

	@Autowired
	private CategoryDAO categoryDAO;

	@Autowired
	private SupplierDAO supplierDAO;

/*	@Autowired
	private ProductDAO productDAO;

	@Autowired
	private UserDAO userDAO; */

	@RequestMapping("/")
	public ModelAndView onLoad(HttpSession session) {
		// log.debug("starting the method onLoad");
		ModelAndView mv = new ModelAndView("/home");
		session.setAttribute("category", "category");
		session.setAttribute("categoryList", categoryDAO.list());
		return mv;
	}
	
/*	@RequestMapping(value = "user/register", method = RequestMethod.POST)
	public ModelAndView registerUser(@ModelAttribute UserDetails userDetails)
	{
		userDAO.saveOrUpdate(userDetails);
		ModelAndView mv =  new ModelAndView("/home");
		mv.addObject("successMessage", " You have successfully registered");
		return mv;
		
	}
	
	@RequestMapping("/Registration")
	public ModelAndView Registration()
	{
		ModelAndView mv = new ModelAndView("/home");
		mv.addObject("userDetails", userDetails);
		mv.addObject("onClickRegistration", "true");
		return mv;
	}
	
	@RequestMapping("/Login")
	public ModelAndView Login()
	{
		ModelAndView mv = new ModelAndView("/home");
		mv.addObject("userDetails", userDetails);
		mv.addObject("onClickLogin", "true");
		return mv;
	}*/
	
}
