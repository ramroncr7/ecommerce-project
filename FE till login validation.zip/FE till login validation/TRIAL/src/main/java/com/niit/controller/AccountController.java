package com.niit.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.niit.entities.*;

@Controller

public class AccountController {
	private Object message;

	@RequestMapping("/Login")
	public ModelAndView accountcontroller()
	{
		return new ModelAndView("welcome","message" , message);
	}

	@RequestMapping( value="/Login", method = RequestMethod.GET)
	public String Login(ModelMap mm){
		mm.put("account", new Account());
		return "Login";
	}

	@RequestMapping( value="/Login", method = RequestMethod.POST)
	public String login(@ModelAttribute(value="account") Account account ,ModelMap mm){
		if(account.getUsername().equals("niit")&& account.getPassword().equals("niit"))
		{
			mm.put("username", account.getUsername());
			return "Home";
		}
		else
		{
			mm.put("message",  "invalid");
		    return "Error";     
		}
	
	}
	
}
