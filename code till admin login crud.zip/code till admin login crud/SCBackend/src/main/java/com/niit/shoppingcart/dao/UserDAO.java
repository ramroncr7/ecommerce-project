package com.niit.shoppingcart.dao;

import java.util.List;

import com.niit.shoppingcart.model.UserDetails;

public interface UserDAO {

	public List<UserDetails> list();
	public UserDetails get(String id);
	public void saveorUpdate(UserDetails userDetails);
	public boolean isValidUser(String id, String password);
	public boolean AdminCheck(String id,boolean isAdmin);
	public void delete(String id);
}
