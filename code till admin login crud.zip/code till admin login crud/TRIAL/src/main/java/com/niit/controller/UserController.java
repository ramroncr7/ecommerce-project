package com.niit.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.niit.shoppingcart.dao.CategoryDAO;
import com.niit.shoppingcart.dao.UserDAO;
import com.niit.shoppingcart.model.Category;

@Controller
public class UserController {
	@Autowired
	UserDAO userDAO;

	@Autowired
	Category category;

	@Autowired
	CategoryDAO categoryDAO;

	@RequestMapping(value = "/loginValidation", method = RequestMethod.POST)
	public ModelAndView loginValidation(@RequestParam(value = "userid") String user_id,
			@RequestParam(value = "password") String password) {
		System.out.println("in user controller");

		String message;
		ModelAndView mv;
		if (userDAO.isValidUser(user_id, password)) {
			message = "Valid credentials";

			boolean isAdmin;
			isAdmin = false;

			if (userDAO.AdminCheck(user_id, isAdmin)) {
				System.out.println("Normal User-Login");
				mv = new ModelAndView("Success");
			} else {
				System.out.println("Admin-Login");
				mv = new ModelAndView("Home");
			}

		} else {
			message = "Invalid credentials";
			mv = new ModelAndView("login");
		}

		mv.addObject("message", message);
		mv.addObject("name", user_id);

		return mv;
	}

	@RequestMapping("/logout")
	public ModelAndView logout(HttpServletRequest request, HttpSession session) {
		ModelAndView mv = new ModelAndView("index");
		session.invalidate();
		session = request.getSession(true);
		session.setAttribute("category", category);
		session.setAttribute("categoryList", categoryDAO.list());

		mv.addObject("logoutMessage", "You successfully logged out");
		mv.addObject("loggedOut", "true");

		return mv;
	}

}
