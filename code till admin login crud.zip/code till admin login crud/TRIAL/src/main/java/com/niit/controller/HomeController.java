package com.niit.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HomeController {

	@RequestMapping("/AboutUs")
	public String showAboutUs() {
		return "AboutUs";
	}

	@RequestMapping("/ContactUs")
	public String showContactUs() {
		return "ContactUs";
	}

	@RequestMapping("/Registration")
	public String showRegistration() {
		return "Registration";
	}

	@RequestMapping("/Cart")
	public String showCart() {
		return "Cart";
	}

	@RequestMapping("/ResetPassword")
	public String showResetPassword() {
		return "ResetPassword";
	}

	@RequestMapping("/Laptop")
	public String showLaptop() {
		return "Laptop";
	}

	@RequestMapping("/Laptop1")
	public String showLaptop1() {
		return "Laptop1";
	}

	@RequestMapping("/Laptop2")
	public String showLaptop2() {
		return "Laptop2";
	}

	@RequestMapping("/Laptop3")
	public String showLaptop3() {
		return "Laptop3";
	}

	@RequestMapping("/Laptop4")
	public String showLaptop4() {
		return "Laptop4";
	}

	@RequestMapping("/Laptop5")
	public String showLaptop5() {
		return "Laptop5";
	}

	@RequestMapping("/Login")
	public String gotoLogin() {
		System.out.println("inside login");
		return "Login";
	}

}
