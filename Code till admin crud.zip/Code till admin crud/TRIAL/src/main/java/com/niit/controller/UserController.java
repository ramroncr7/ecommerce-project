package com.niit.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.niit.shoppingcart.dao.UserDAO;


@Controller
public class UserController {
	 @Autowired
		UserDAO userDAO;


	@RequestMapping("/isValidUser")
		public ModelAndView showMessage(@RequestParam(value = "name") String id,
				@RequestParam(value = "password") String password) {
			System.out.println("in user controller");

			String message;
			ModelAndView mv ;
			if (userDAO.isValidUser(id, password,true)) 
			{
				message = "Valid credentials";
				 mv = new ModelAndView("Home");
			} else {
				message = "Invalid credentials";
				 mv = new ModelAndView("Login");
			}

			//ModelAndView mv = new ModelAndView("success");
			mv.addObject("message", message);
			mv.addObject("name", id);
			// mv.addObject("password", password);
			return mv;
		}

}

